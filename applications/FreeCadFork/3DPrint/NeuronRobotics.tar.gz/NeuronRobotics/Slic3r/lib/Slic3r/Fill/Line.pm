package Slic3r::Fill::Line;
use Moo;

extends 'Slic3r::Fill::Rectilinear';

# Sorry for breaking OOP, but Line is implemented inside Rectilinear.

1;
